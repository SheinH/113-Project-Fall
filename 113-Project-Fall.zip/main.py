import matplotlib.pyplot as plt
import numpy as np

from letter_classifier_manual import LetterClassifierManual
from letter_classsifier_machine import LetterClassifierMachine

import os


def average_hit_missed():
    hit_miss_percent = []
    d = {}
    d['L'] = 0
    d['H'] = 0

    for i in range(10000):

        match, miss = train_and_run(d)
        hit_miss_percent.append(match / (match + miss))
    print(np.mean(hit_miss_percent))
    print(d['H'], d['L'])
    return hit_miss_percent


def train_and_run(d):
    manual_classifier = LetterClassifierManual()
    manual_classifier.classifyLetters()
    manual_classifier.classifyLettersTest()

    machine_classifier = LetterClassifierMachine()
    machine_classifier.setup()

    machine_classifier.train_l_set()
    machine_classifier.train_h_set()
    cwd = os.getcwd()

    f = open(cwd + '/Data/Test Data.txt', 'r')
    match, miss = 0, 0
    for line in f:
        if(line.strip() != ''):
            classification = line.strip().split(',')[-1]
            letter = line.strip().split(',')[:-1]
            c = machine_classifier.classify(letter)
            if(c == None):
                print('NONE')
            elif (c == classification):
                match += 1
            else:
                if (classification == 'L'):
                    d['L'] += 1
                else:
                    d['H'] += 1
                miss += 1
    choice_set = machine_classifier.choice_sets
    if(match / (match + miss) < .90):
        if(str(choice_set) in d):
            d[str(choice_set)] += 1
        else:
            d[str(choice_set)] = 1

    machine_classifier.reset()
    f.close()


    return match, miss

def main():
    fig = plt.figure(figsize=(10, 10))

    plt.hist(average_hit_missed(), bins=100, histtype='step')
    plt.xlabel('Accuracy Percentage')
    plt.ylabel('Occurrences')
    plt.title('Histogram of 10K Runs for Letter Classifier')
    plt.show()


main()
